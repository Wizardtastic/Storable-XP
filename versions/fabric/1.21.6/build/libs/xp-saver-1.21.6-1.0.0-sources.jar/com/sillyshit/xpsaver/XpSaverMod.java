package com.sillyshit.xpsaver;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XpSaverMod implements ModInitializer {
    public static final String MOD_ID = "xp_saver";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_1792 XP_STORAGE_BOTTLE = new XpStorageBottleItem(new class_1792.class_1793().method_7889(1).method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MOD_ID, "xp_storage_bottle"))));

    @Override
    public void onInitialize() {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "xp_storage_bottle"), XP_STORAGE_BOTTLE);
        LOGGER.info("XP Saver loaded!");
    }
}