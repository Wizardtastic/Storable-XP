package com.sillyshit.xpsaver;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5328;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class XpStorageBottleItem extends class_1792 {

    private static final String XP_KEY = "stored_xp";

    public XpStorageBottleItem(class_1793 settings) {
        super(settings);
    }

    public static int getStoredXp(class_1799 stack) {
        class_9279 data = stack.method_57825(class_9334.field_49628, class_9279.field_49302);
        class_2487 tag = data.method_57461();
        return tag.method_10545(XP_KEY) ? tag.method_10550(XP_KEY) : 0;
    }

    public static void setStoredXp(class_1799 stack, int amount) {
        if (amount <= 0) {
            stack.method_57381(class_9334.field_49628);
        } else {
            class_2487 tag = new class_2487();
            tag.method_10569(XP_KEY, amount);
            stack.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
        }
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        if (player.method_5715()) {
            int playerXp = getPlayerTotalXp(player);
            if (playerXp <= 0) {
                if (!world.field_9236) {
                    player.method_7353(class_2561.method_43471("message.xp_saver.no_xp").method_27692(class_124.field_1061), true);
                }
                return class_1269.field_5814;
            }

            if (!world.field_9236) {
                int stored = getStoredXp(stack);
                int newTotal = stored + playerXp;
                setStoredXp(stack, newTotal);
                player.field_7495 = 0;
                player.field_7520 = 0;
                player.field_7510 = 0.0f;
                world.method_8396(null, player.method_24515(), class_3417.field_14627,
                        class_3419.field_15248, 1.0f, 1.0f);
                player.method_7353(class_2561.method_43469("message.xp_saver.stored", playerXp, newTotal)
                        .method_27692(class_124.field_1060), true);
            }
            return class_1269.field_5812;
        }

        int stored = getStoredXp(stack);
        if (stored <= 0) {
            if (!world.field_9236) {
                player.method_7353(class_2561.method_43471("message.xp_saver.empty").method_27692(class_124.field_1061), true);
            }
            return class_1269.field_5814;
        }

        return class_5328.method_29282(world, player, hand);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (user instanceof class_1657 player && !world.field_9236) {
            int stored = getStoredXp(stack);
            if (stored > 0) {
                player.method_7255(stored);
                setStoredXp(stack, 0);
                world.method_8396(null, player.method_24515(), class_3417.field_14709,
                        class_3419.field_15248, 0.5f, 1.0f);
                player.method_7353(class_2561.method_43469("message.xp_saver.drank", stored).method_27692(class_124.field_1060), true);
            }
        }
        return method_7854();
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 user) {
        return 32;
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8946;
    }

    @Override
    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 type) {
        int stored = getStoredXp(stack);
        if (stored > 0) {
            tooltip.add(class_2561.method_43469("tooltip.xp_saver.stored_xp", stored).method_27692(class_124.field_1075));
        } else {
            tooltip.add(class_2561.method_43471("tooltip.xp_saver.empty").method_27692(class_124.field_1080));
        }
    }

    private int getPlayerTotalXp(class_1657 player) {
        int level = player.field_7520;
        float progress = player.field_7510;
        int total = 0;
        for (int i = 0; i < level; i++) {
            total += getXpRequiredForLevel(i);
        }
        total += (int) (progress * getXpRequiredForLevel(level));
        return total;
    }

    private int getXpRequiredForLevel(int level) {
        if (level >= 30) {
            return 62 + (level - 30) * 7;
        } else if (level >= 15) {
            return 17 + (level - 15) * 3;
        } else {
            return 2 * level + 7;
        }
    }
}